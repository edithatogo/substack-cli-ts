#!/usr/bin/env node
import { readFile, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { mkdirSync } from "node:fs";
import { randomUUID } from "node:crypto";

const outputFile = process.argv[2] ?? "reports/sbom/package-lock-sbom.json";

const packageJson = JSON.parse(await readFile("package.json", "utf8"));
const packageLock = JSON.parse(await readFile("package-lock.json", "utf8"));
const packages = packageLock.packages ?? {};

const components = Object.entries(packages)
  .filter(([path]) => path.startsWith("node_modules/"))
  .map(([path, metadata]) => {
    const name = metadata.name ?? path.replace(/^node_modules\//, "");
    const version = metadata.version ?? "0.0.0";
    return {
      type: "library",
      name,
      version,
      purl: `pkg:npm/${encodeURIComponent(name)}@${encodeURIComponent(version)}`,
      scope: metadata.dev ? "development" : "required",
    };
  })
  .sort((left, right) => `${left.name}@${left.version}`.localeCompare(`${right.name}@${right.version}`));

const sbom = {
  bomFormat: "CycloneDX",
  specVersion: "1.5",
  serialNumber: `urn:uuid:${randomUUID()}`,
  version: 1,
  metadata: {
    component: {
      type: "application",
      name: packageJson.name,
      version: packageJson.version,
    },
    tools: [
      {
        vendor: packageJson.name,
        name: "scripts/generate-sbom.mjs",
      },
    ],
  },
  components,
};

mkdirSync(dirname(outputFile), { recursive: true });
await writeFile(outputFile, `${JSON.stringify(sbom, null, 2)}\n`, "utf8");
console.log(JSON.stringify({ outputFile, components: components.length }, null, 2));
