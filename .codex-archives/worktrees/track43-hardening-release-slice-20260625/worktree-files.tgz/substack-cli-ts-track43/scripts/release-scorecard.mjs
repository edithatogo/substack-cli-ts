#!/usr/bin/env node
import { mkdir, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import {
  buildReleaseScorecard,
  renderReleaseScorecard,
} from "../dist/frontier-coverage/launch-checklist.js";

const args = process.argv.slice(2);
const outIndex = args.indexOf("--out");
const formatIndex = args.indexOf("--format");
const out = outIndex >= 0 ? args[outIndex + 1] : undefined;
const format = formatIndex >= 0 ? args[formatIndex + 1] : "markdown";

if (format !== "json" && format !== "markdown") {
  throw new Error("Unsupported release scorecard format. Use json or markdown.");
}

const scorecard = buildReleaseScorecard();
const output =
  format === "markdown"
    ? renderReleaseScorecard(scorecard)
    : `${JSON.stringify(scorecard, null, 2)}\n`;

if (out) {
  await mkdir(dirname(out), { recursive: true });
  await writeFile(out, output, "utf8");
  console.log(JSON.stringify({ operation: "release.scorecard", outputFile: out }));
} else {
  process.stdout.write(output);
}

if (scorecard.status === "blocked") {
  process.exitCode = 1;
}
