#!/usr/bin/env node
import { readFile } from "node:fs/promises";

const packageJson = JSON.parse(await readFile("package.json", "utf8"));
const publishWorkflow = await readFile(".github/workflows/publish.yml", "utf8");

const checks = [
  {
    id: "publish-uses-provenance",
    ok: publishWorkflow.includes("npm publish --provenance --access public"),
  },
  {
    id: "workflow-has-oidc",
    ok: /id-token:\s*write/.test(publishWorkflow),
  },
  {
    id: "package-is-public",
    ok: packageJson.private === false && packageJson.publishConfig?.access === "public",
  },
  {
    id: "registry-package",
    ok: packageJson.name === "@edithatogo/substack-cli" && packageJson.mcpName,
  },
];

const failed = checks.filter((check) => !check.ok);

console.log(
  JSON.stringify(
    {
      operation: "release.provenance-check",
      status: failed.length === 0 ? "ready" : "blocked",
      checks,
    },
    null,
    2,
  ),
);

if (failed.length > 0) {
  process.exitCode = 1;
}
