import assert from "node:assert/strict";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, it } from "vitest";
import { buildAnalyticsSnapshot } from "./growth.js";
import { buildAttributionReport, buildWarehouseExport, writeWarehouseExport } from "./warehouse.js";

describe("creator warehouse exports", () => {
  it("normalizes campaigns, analytics probes, referrers, revenue, and run logs", async () => {
    const temp = await mkdtemp(join(tmpdir(), "substack-warehouse-"));
    try {
      const campaignFile = join(temp, "campaign.json");
      const analyticsDir = join(temp, "analytics");
      const runLogDir = join(temp, "run-log");
      await writeFile(campaignFile, JSON.stringify(campaignPlan(), null, 2));
      await mkdir(analyticsDir);
      await writeFile(
        join(analyticsDir, "snapshot.json"),
        JSON.stringify(
          buildAnalyticsSnapshot({
            postId: 7,
            campaignId: "creator-os",
            analytics: analyticsInventory(),
          }),
          null,
          2,
        ),
      );
      await mkdir(runLogDir);
      await writeFile(
        join(runLogDir, "run.json"),
        JSON.stringify({
          schemaVersion: 1,
          timestamp: "2099-01-01T00:00:00Z",
          actionType: "campaign.plan",
          status: "success",
          publicationUrl: "local",
          sourceFile: "post.md",
          title: "Post",
          campaignId: "creator-os",
          resultMessage: "ok",
        }),
      );

      const warehouse = await buildWarehouseExport({
        campaignFiles: [campaignFile],
        analyticsDir,
        runLogDir,
      });
      assert.equal(warehouse.tables.campaigns.length, 1);
      assert.equal(warehouse.tables.notes.length, 1);
      assert.equal(warehouse.tables.referrers.length, 1);
      assert.equal(warehouse.tables.subscribers.length, 1);
      assert.equal(warehouse.tables.revenue.length, 1);
      assert.equal(warehouse.tables.run_logs.length, 1);

      const report = buildAttributionReport(warehouse);
      assert.equal(report.campaigns[0]?.campaignId, "creator-os");
      assert.equal(report.campaigns[0]?.views, 42);
      assert.equal(report.campaigns[0]?.revenue, 123);

      const written = await writeWarehouseExport(warehouse, join(temp, "out"), "both");
      assert.ok(written.files.some((file) => file.endsWith("warehouse.json")));
      assert.match(await readFile(join(temp, "out", "referrers.csv"), "utf8"), /reader/);
    } finally {
      await rm(temp, { recursive: true, force: true });
    }
  });
});

function campaignPlan() {
  return {
    schemaVersion: 1,
    status: "ready",
    campaignId: "creator-os",
    createdAt: "2099-01-01T00:00:00Z",
    post: {
      filePath: "post.md",
      title: "Post",
      slug: "post",
      plannedUrl: "https://example.substack.com/p/post",
    },
    publishAt: "2099-01-02T00:00:00Z",
    notes: [
      {
        scheduledAt: "2099-01-02T01:00:00Z",
        postUrl: "https://example.substack.com/p/post",
        text: "New post https://example.substack.com/p/post",
        status: "planned",
      },
    ],
    channels: [{ channel: "notes", plannedAction: "Schedule covering Notes around the post URL." }],
    assets: [],
    utm: { source: "substack-cli", medium: "campaign", campaign: "creator-os" },
    issues: [],
    nextCommands: [],
  };
}

function analyticsInventory() {
  return {
    status: "ok" as const,
    endpoints: [],
    message: "ok",
    postAnalytics: {
      status: "ok" as const,
      message: "ok",
      analytics: {
        postId: 7,
        title: "Post",
        views: 100,
        readRate: 0.6,
        emailOpens: 80,
        emailClicks: 20,
        referrers: [{ source: "reader", views: 42 }],
      },
    },
    subscriberGrowth: {
      status: "ok" as const,
      message: "ok",
      growth: {
        period: "week",
        totalSubscribers: 1000,
        netChange: 50,
        freeSubscribers: 900,
        paidSubscribers: 100,
        churned: 2,
      },
    },
    emailPerformance: null,
    revenue: {
      status: "ok" as const,
      message: "ok",
      revenue: {
        period: "week",
        newPaidSubscribers: 5,
        churnedPaidSubscribers: 1,
        mrr: 456,
        totalRevenue: 123,
      },
    },
  };
}
