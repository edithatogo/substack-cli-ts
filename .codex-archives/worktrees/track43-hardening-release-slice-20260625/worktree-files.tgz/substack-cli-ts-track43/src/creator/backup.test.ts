import assert from "node:assert/strict";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, it } from "vitest";
import {
  buildBackupSnapshotPlan,
  validateBackupSnapshotFile,
  writeBackupSnapshotPlan,
} from "./backup.js";

describe("creator backup plans", () => {
  it("builds redacted backup plans and validates restore checklists", async () => {
    const temp = await mkdtemp(join(tmpdir(), "substack-backup-"));
    try {
      const source = join(temp, "warehouse.json");
      const snapshot = join(temp, "snapshot.json");
      await writeFile(source, "{}");

      const plan = await buildBackupSnapshotPlan({
        snapshotFile: snapshot,
        publicationUrl: "https://private.example/p/account@example.com",
        sources: [source],
      });
      assert.equal(plan.status, "ready");
      assert.match(plan.publicationUrl ?? "", /\[REDACTED_EMAIL\]/);
      assert.ok(plan.manualRestoreChecklist.length >= 3);

      await writeBackupSnapshotPlan(plan, snapshot);
      const validation = await validateBackupSnapshotFile(snapshot);
      assert.equal(validation.status, "ready");
    } finally {
      await rm(temp, { recursive: true, force: true });
    }
  });

  it("blocks missing sources", async () => {
    const plan = await buildBackupSnapshotPlan({
      snapshotFile: "snapshot.json",
      sources: ["missing.json"],
    });
    assert.equal(plan.status, "blocked");
  });
});
