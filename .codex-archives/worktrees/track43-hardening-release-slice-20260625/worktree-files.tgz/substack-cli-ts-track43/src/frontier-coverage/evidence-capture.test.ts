import assert from "node:assert/strict";
import { describe, it } from "vitest";
import {
  buildCaptureValidationReport,
  buildEndpointDiffReport,
  buildEndpointInventoryReport,
  buildGraduationCheckReport,
  minimizeCaptureFixture,
  parseCaptureEvidenceFixture,
  renderEndpointInventory,
  type CaptureEvidenceFixture,
} from "./evidence-capture.js";
import type { CoverageMatrix } from "./schema.js";

describe("capture evidence fixtures", () => {
  it("redacts and minimizes sensitive endpoint capture data", () => {
    const minimized = minimizeCaptureFixture(fixture(), {
      verifiedAt: new Date("2026-06-24T00:00:00.000Z"),
    });
    const serialized = JSON.stringify(minimized);

    assert.equal(minimized.capabilityId, "analytics-growth-revenue");
    assert.equal(minimized.lastVerifiedAt, "2026-06-24T00:00:00.000Z");
    assert.equal(minimized.endpoints[0]?.requestHeaders?.authorization, "[REDACTED]");
    assert.equal(minimized.endpoints[0]?.requestBody, undefined);
    assert.match(minimized.evidenceHash, /^[a-f0-9]{64}$/);
    assert.doesNotMatch(serialized, /owner@example.com/);
    assert.doesNotMatch(serialized, /Jane Creator/);
    assert.doesNotMatch(serialized, /sk_live_/);
    assert.doesNotMatch(serialized, /123456789/);
  });

  it("validates parse shape and blocked minimized captures", () => {
    const parsed = parseCaptureEvidenceFixture(fixture());
    const report = buildCaptureValidationReport(
      {
        ...parsed,
        endpoints: [{ method: "GET", url: "https://example.substack.com/api/v1/stats" }],
      },
      { verifiedAt: new Date("2026-06-24T00:00:00.000Z") },
    );

    assert.equal(parsed.source, "browser");
    assert.equal(report.status, "blocked");
    assert.equal(report.issues[0]?.code, "empty-evidence");
    assert.throws(() => parseCaptureEvidenceFixture({}));
  });
});

describe("endpoint inventory and diff reports", () => {
  it("renders a stable endpoint inventory", () => {
    const report = buildEndpointInventoryReport([fixture()], {
      generatedAt: new Date("2026-06-24T01:00:00.000Z"),
    });
    const markdown = renderEndpointInventory(report);

    assert.equal(report.operation, "coverage.endpoint.inventory");
    assert.equal(report.status, "ready");
    assert.equal(report.endpointCount, 1);
    assert.equal(report.entries[0]?.path, "/api/v1/stats");
    assert.match(markdown, /Endpoint Capture Inventory/);
    assert.match(markdown, /analytics-growth-revenue/);
  });

  it("reports added, removed, and changed endpoints", () => {
    const before = buildEndpointInventoryReport([fixture()], {
      generatedAt: new Date("2026-06-24T01:00:00.000Z"),
    });
    const after = buildEndpointInventoryReport(
      [
        fixture({
          status: 206,
          responseBody: { metrics: ["opens"], email: "owner@example.com" },
        }),
        fixture({
          method: "POST",
          url: "https://example.substack.com/api/v1/reports",
          responseBody: { ok: true },
        }),
      ],
      { generatedAt: new Date("2026-06-24T02:00:00.000Z") },
    );

    const diff = buildEndpointDiffReport(before, after);

    assert.equal(diff.status, "blocked");
    assert.equal(diff.added.length, 1);
    assert.equal(diff.removed.length, 0);
    assert.ok(diff.changed.some((entry) => entry.changes.includes("status")));
  });
});

describe("graduation checks", () => {
  it("blocks probe, planning, and manual surfaces without capture and manual evidence", () => {
    const report = buildGraduationCheckReport(matrix(), buildEndpointInventoryReport([fixture()]), {
      checkedAt: new Date("2026-06-24T00:00:00.000Z"),
    });

    assert.equal(report.status, "blocked");
    assert.deepEqual(report.blockers[0]?.missing, [
      "manual validation or recovery evidence",
      "endpoint-capture evidence link",
    ]);
    assert.deepEqual(report.blockers[1]?.missing, [
      "redacted endpoint capture fixture",
      "manual validation or recovery evidence",
      "endpoint-capture evidence link",
    ]);
  });

  it("passes when every conservative surface has capture, manual evidence, and decisions", () => {
    const matrixWithEvidence = matrix({
      evidence: [
        { kind: "endpoint-capture", label: "Capture", ref: "fixtures/captures/analytics.json" },
        { kind: "manual-check", label: "Manual recovery", ref: "docs/frontier-capture-kit.md" },
      ],
    });
    const report = buildGraduationCheckReport(
      matrixWithEvidence,
      buildEndpointInventoryReport([fixture(), fixture({ capabilityId: "native-video-posts" })]),
    );

    assert.equal(report.status, "ready");
    assert.equal(report.blockers.length, 0);
  });
});

function fixture(overrides: Partial<CaptureEvidenceFixture["endpoints"][number]> & {
  capabilityId?: string;
} = {}): CaptureEvidenceFixture {
  return {
    schemaVersion: 1,
    capabilityId: overrides.capabilityId ?? "analytics-growth-revenue",
    capturedAt: "2026-06-24T00:00:00.000Z",
    source: "browser",
    surface: "Dashboard analytics for Jane Creator",
    endpoints: [
      {
        method: overrides.method ?? "GET",
        url:
          overrides.url ??
          "https://example.substack.com/api/v1/stats?email=owner@example.com&publication_id=123456789",
        status: overrides.status ?? 200,
        requestHeaders: {
          authorization: "Bearer sk_live_abcdefghijklmnopqrstuvwxyz",
          cookie: "substack.sid=secret",
          accept: "application/json",
        },
        requestBody: overrides.requestBody,
        responseHeaders: { "content-type": "application/json", "set-cookie": "sid=secret" },
        responseBody:
          overrides.responseBody ?? {
            subscriber_email: "owner@example.com",
            display_name: "Jane Creator",
            publication_id: 123456789,
            metrics: [{ post_id: "123456789", opens: 42 }],
          },
      },
    ],
    notes: ["Captured from account owner@example.com"],
  };
}

function matrix(
  evidenceOverride?: Pick<CoverageMatrix["capabilities"][number], "evidence">,
): CoverageMatrix {
  return {
    schemaVersion: 1,
    capabilities: [
      {
        id: "analytics-growth-revenue",
        name: "Analytics",
        domain: "analytics-revenue",
        status: "probe-only",
        paths: ["cli", "browser", "manual-admin"],
        primaryPath: "cli",
        fallbackPath: "browser",
        manualPath: "manual-admin",
        safetyClass: "read-only",
        evidence: evidenceOverride?.evidence ?? [],
        decisionRecord: { id: "DR-analytics", reason: "Capture first." },
        nextAction: "Capture endpoints.",
      },
      {
        id: "native-video-posts",
        name: "Native video",
        domain: "native-media",
        status: "planning-only",
        paths: ["cli", "mcp-planning", "manual-admin"],
        primaryPath: "cli",
        fallbackPath: "mcp-planning",
        manualPath: "manual-admin",
        safetyClass: "planning-only",
        evidence: evidenceOverride?.evidence ?? [],
        decisionRecord: { id: "DR-video", reason: "Capture first." },
        nextAction: "Capture endpoints.",
      },
    ],
  };
}
