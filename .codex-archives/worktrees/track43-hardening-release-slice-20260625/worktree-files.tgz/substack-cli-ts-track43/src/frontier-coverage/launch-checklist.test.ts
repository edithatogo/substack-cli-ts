import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { describe, it } from "vitest";
import {
  FRONTIER_LAUNCH_CHECKLIST,
  FRONTIER_LAUNCH_CHECKLIST_PATH,
  REQUIRED_LAUNCH_SURFACES,
  buildReleaseScorecard,
  renderLaunchChecklist,
  renderReleaseScorecard,
  validateLaunchChecklist,
} from "./launch-checklist.js";

describe("frontier launch checklist", () => {
  it("covers every required external launch and admin surface", () => {
    const validation = validateLaunchChecklist();

    assert.equal(validation.status, "ready");
    assert.deepEqual(validation.missing, []);
    for (const surface of REQUIRED_LAUNCH_SURFACES) {
      assert.ok(
        FRONTIER_LAUNCH_CHECKLIST.some((item) => item.surface === surface),
        surface,
      );
    }
  });

  it("requires missing surfaces to be added before readiness", () => {
    const validation = validateLaunchChecklist(
      FRONTIER_LAUNCH_CHECKLIST.filter((item) => item.surface !== "npm"),
    );

    assert.equal(validation.status, "blocked");
    assert.deepEqual(validation.missing, ["npm"]);
  });

  it("renders account-gated boundaries and rollback guidance", () => {
    const markdown = renderLaunchChecklist();

    assert.match(markdown, /^# Frontier Launch and Admin Checklist/);
    assert.match(markdown, /Manual and Account-Gated Boundaries/);
    assert.match(markdown, /npm package publication/);
    assert.match(markdown, /Substack publication admin follow-through/);
    assert.match(markdown, /Rollback:/);
  });

  it("keeps the checked-in checklist synchronized with the renderer", async () => {
    const checkedIn = await readFile(FRONTIER_LAUNCH_CHECKLIST_PATH, "utf8");

    assert.equal(checkedIn.replace(/\r\n/g, "\n"), renderLaunchChecklist().replace(/\r\n/g, "\n"));
  });

  it("builds a release scorecard that separates local readiness from owner gates", () => {
    const scorecard = buildReleaseScorecard();

    assert.equal(scorecard.operation, "release.scorecard");
    assert.equal(scorecard.status, "ready");
    assert.ok(scorecard.summary.ready >= 1);
    assert.ok(scorecard.summary.ownerGated >= 1);
    assert.ok(scorecard.summary.advisory >= 1);
    assert.equal(scorecard.summary.blocked, 0);
    assert.ok(scorecard.gates.some((gate) => gate.id === "sbom-provenance"));
    assert.ok(scorecard.gates.some((gate) => gate.id === "external-launch"));
  });

  it("renders the release scorecard with advisory and owner/admin boundaries", () => {
    const markdown = renderReleaseScorecard();

    assert.match(markdown, /^# Release and External Launch Scorecard/);
    assert.match(markdown, /Advisory gates:/);
    assert.match(markdown, /Owner\/admin gated gates:/);
    assert.match(markdown, /npm publish, GitHub Release creation/);
  });
});
