# Branch Protection and Release Hardening

This policy documents the checks that should protect release and dependency work without pretending advisory hardening lanes are already mandatory.

## Required Checks

Require these checks for feature pull requests before merge:

- `Quality`
- `Smoke`

Keep `Mutation` advisory until module-level thresholds are stable. Keep `E2E` workflow-dispatch only because it needs live Substack credentials and a test publication.

## Advisory Checks

Run these checks on pull requests and review failures before release, but do not make them required until false positives and dependency churn are controlled:

- `Strictest TypeScript (Advisory)`
- `Audit, Secret Scan, SBOM, and Provenance (Advisory)`
- `Mutation`

The hardening lane runs production audit, secret scanning, local SBOM generation, provenance configuration validation, and release scorecard generation. It uploads SBOM and scorecard artifacts for review.

## Dependency Pull Requests

Dependency PRs may use automerge only when all required checks pass and the PR is not labeled `breaking`.

- Stable dependency PRs should run `Quality` and `Smoke`.
- Parser or Tiptap dependency PRs should also run `npm test` and `node dist/cli.js inspect examples/basic.md`.
- Browser, Playwright, or Stagehand dependency PRs should run smoke locally and dispatch E2E before release.
- Security update PRs should run `npm run audit:prod` and `npm run scan:secrets`.

## Experimental Dependency Lanes

Experimental dependency checks are workflow-dispatch only and advisory. Use them to test future compiler, browser, and test-runner compatibility without changing the normal dependency tree.

Current lanes:

- `typescript-next`
- `playwright-next`

Do not enable automerge for experimental package versions. Promote findings into a dedicated dependency branch after the advisory lane is reviewed.

## Release Ruleset Notes

Before cutting a tag, confirm:

- `Quality`, `Smoke`, and the release workflow are green on the release commit.
- The hardening lane artifacts include an SBOM and current release scorecard.
- `npm publish --provenance --access public` remains in `.github/workflows/publish.yml`.
- External npm, GitHub Release, MCP registry, marketplace, and Substack admin gates remain owner-approved.
